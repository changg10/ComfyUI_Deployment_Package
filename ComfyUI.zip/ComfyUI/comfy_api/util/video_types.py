# This file only exists for backwards compatibility.
from comfy_api.latest._util.video_types import (
    VideoContainer,
    VideoCodec,
    VideoComponents,
)

__all__ = [
    "VideoContainer",
    "VideoCodec",
    "VideoComponents",
]
